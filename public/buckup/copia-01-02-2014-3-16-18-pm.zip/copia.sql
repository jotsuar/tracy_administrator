#
# TABLE STRUCTURE FOR: banco
#

CREATE TABLE `banco` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nit` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `numero_cuenta` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO banco (`id`, `nit`, `nombre`, `direccion`, `telefono`, `numero_cuenta`, `estado`) VALUES (1, '267876', 'AV VILLAS', 'CALLE 32 #4534', '37480094', '45884774', 1);
INSERT INTO banco (`id`, `nit`, `nombre`, `direccion`, `telefono`, `numero_cuenta`, `estado`) VALUES (2, '12345678', 'BANCO POPULAR', 'PARQUE BERRIO', '7883993', '86254168', 1);
INSERT INTO banco (`id`, `nit`, `nombre`, `direccion`, `telefono`, `numero_cuenta`, `estado`) VALUES (3, '8973651627', 'BANCO DE BOGOTÁ', 'CALLE 77 # 31-20', '3456782', '985004978', 1);
INSERT INTO banco (`id`, `nit`, `nombre`, `direccion`, `telefono`, `numero_cuenta`, `estado`) VALUES (4, '77353628', 'BBVA', 'POBLADO CENTER', '444556677', '2039039030', 1);
INSERT INTO banco (`id`, `nit`, `nombre`, `direccion`, `telefono`, `numero_cuenta`, `estado`) VALUES (5, '267876', 'AV VILLAS', 'CALLE 32 #4534', '37480094', '88837654', 1);


#
# TABLE STRUCTURE FOR: buckup
#

CREATE TABLE `buckup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `ruta` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO buckup (`id`, `fecha`, `ruta`) VALUES (1, '2014-02-01', 0);


#
# TABLE STRUCTURE FOR: categoria
#

CREATE TABLE `categoria` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `categoria` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO categoria (`id`, `categoria`, `descripcion`) VALUES (1, '5 ESTRELLAS', '');
INSERT INTO categoria (`id`, `categoria`, `descripcion`) VALUES (2, '4 ESTRELLAS', '');
INSERT INTO categoria (`id`, `categoria`, `descripcion`) VALUES (3, '3 ESTRELLAS', '');
INSERT INTO categoria (`id`, `categoria`, `descripcion`) VALUES (4, '2 ESTRELLAS', '');
INSERT INTO categoria (`id`, `categoria`, `descripcion`) VALUES (5, '1 ESTRELLAS', '');


#
# TABLE STRUCTURE FOR: citytour
#

CREATE TABLE `citytour` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `direccion_salida` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `estado` bit(1) NOT NULL DEFAULT b'1',
  `id_vehiculo` int(10) unsigned DEFAULT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `valor` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_citytour_id_vehiculo` (`id_vehiculo`),
  CONSTRAINT `fk_citytour_id_vehiculo` FOREIGN KEY (`id_vehiculo`) REFERENCES `vehiculo` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO citytour (`id`, `fecha`, `hora_inicio`, `hora_fin`, `direccion_salida`, `estado`, `id_vehiculo`, `nombre`, `valor`) VALUES (1, '2014-03-06', '14:00:00', '20:00:00', 'Carrera 50 #58-67', 1, 2, 'La calle del terror', '0');
INSERT INTO citytour (`id`, `fecha`, `hora_inicio`, `hora_fin`, `direccion_salida`, `estado`, `id_vehiculo`, `nombre`, `valor`) VALUES (2, '2014-03-07', '17:03:00', '07:00:00', 'Calle 33 #567-576', 1, 2, 'El amor fluye', '0');


#
# TABLE STRUCTURE FOR: cliente_externo
#

CREATE TABLE `cliente_externo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `identificacion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `edad` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

#
# TABLE STRUCTURE FOR: cliente_externo_reserva
#

CREATE TABLE `cliente_externo_reserva` (
  `id_reserva` int(10) unsigned NOT NULL,
  `id_cliente_externo` int(10) unsigned NOT NULL,
  KEY `cliente_externo_reserva_id_reserva_idx` (`id_reserva`),
  KEY `cliente_externo_reserva_id_cliente_externo_idx` (`id_cliente_externo`),
  CONSTRAINT `cliente_externo_reserva_id_cliente_externo` FOREIGN KEY (`id_cliente_externo`) REFERENCES `cliente_externo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cliente_externo_reserva_id_reserva` FOREIGN KEY (`id_reserva`) REFERENCES `reserva` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

#
# TABLE STRUCTURE FOR: contacto
#

CREATE TABLE `contacto` (
  `codigo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identificacion` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `nombres` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `celular` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `estado` bit(1) NOT NULL DEFAULT b'1',
  `id_hospedaje` int(10) unsigned DEFAULT NULL,
  `id_transporte` int(10) unsigned DEFAULT NULL,
  `id_evento` int(10) unsigned DEFAULT NULL,
  `sitio_turistico` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  KEY `contacto_id_hospedaje` (`id_hospedaje`),
  KEY `contacto_id_transporte_idx` (`id_transporte`),
  KEY `contacto_id_evento_idx` (`id_evento`),
  KEY `fk_contacto_sitio_turistico1_idx` (`sitio_turistico`),
  CONSTRAINT `contacto_id_evento` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `contacto_id_hospedaje` FOREIGN KEY (`id_hospedaje`) REFERENCES `hospedaje` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `contacto_id_transporte` FOREIGN KEY (`id_transporte`) REFERENCES `transporte` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_contacto_sitio_turistico1` FOREIGN KEY (`sitio_turistico`) REFERENCES `sitio_turistico` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO contacto (`codigo`, `identificacion`, `nombres`, `apellidos`, `celular`, `email`, `estado`, `id_hospedaje`, `id_transporte`, `id_evento`, `sitio_turistico`) VALUES (1, '10351234552', 'jhonatan', 'suarez', '30018338389', 'jotver_01@hotmail.ar', 1, NULL, NULL, 1, NULL);
INSERT INTO contacto (`codigo`, `identificacion`, `nombres`, `apellidos`, `celular`, `email`, `estado`, `id_hospedaje`, `id_transporte`, `id_evento`, `sitio_turistico`) VALUES (2, '98989898', 'Camilo Andres', 'Morientes', '30018338389', 'jotver_01@hotmail.com', 1, NULL, 1, NULL, NULL);
INSERT INTO contacto (`codigo`, `identificacion`, `nombres`, `apellidos`, `celular`, `email`, `estado`, `id_hospedaje`, `id_transporte`, `id_evento`, `sitio_turistico`) VALUES (3, '111111', 'Diego Leon', 'Carmona', '30309309', 'diego@tupapito.com', 1, 1, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: convenio
#

CREATE TABLE `convenio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero_convenio` int(10) unsigned DEFAULT NULL,
  `fecha` date NOT NULL,
  `id_hospedaje` int(10) unsigned DEFAULT NULL,
  `tipo_convenio` int(10) unsigned DEFAULT NULL,
  `id_transporte` int(10) unsigned DEFAULT NULL,
  `id_sitio_turistico` int(10) unsigned DEFAULT NULL,
  `costo` float unsigned DEFAULT NULL,
  `venta` float unsigned DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `estado` bit(1) DEFAULT b'1',
  `id_banco` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_hotel_idx` (`id_hospedaje`),
  KEY `Nit_empresa_idx` (`id_transporte`),
  KEY `id_sitio_turistico_idx` (`id_sitio_turistico`),
  KEY `convenio_banco_id_idx` (`id_banco`),
  CONSTRAINT `convenio_banco_id` FOREIGN KEY (`id_banco`) REFERENCES `banco` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `id_hospedaje` FOREIGN KEY (`id_hospedaje`) REFERENCES `hospedaje` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `id_sitio_turistico` FOREIGN KEY (`id_sitio_turistico`) REFERENCES `sitio_turistico` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `Nit_empresa` FOREIGN KEY (`id_transporte`) REFERENCES `transporte` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO convenio (`id`, `numero_convenio`, `fecha`, `id_hospedaje`, `tipo_convenio`, `id_transporte`, `id_sitio_turistico`, `costo`, `venta`, `fecha_inicio`, `fecha_fin`, `estado`, `id_banco`) VALUES (1, 4294967295, '2013-11-25', NULL, 3, NULL, 3, '55555', '99999', '2013-11-25', '2014-07-17', 1, NULL);
INSERT INTO convenio (`id`, `numero_convenio`, `fecha`, `id_hospedaje`, `tipo_convenio`, `id_transporte`, `id_sitio_turistico`, `costo`, `venta`, `fecha_inicio`, `fecha_fin`, `estado`, `id_banco`) VALUES (2, 454545, '2013-11-25', NULL, 3, NULL, 1, '3333', '3333', '2014-03-07', '2014-09-25', 1, NULL);
INSERT INTO convenio (`id`, `numero_convenio`, `fecha`, `id_hospedaje`, `tipo_convenio`, `id_transporte`, `id_sitio_turistico`, `costo`, `venta`, `fecha_inicio`, `fecha_fin`, `estado`, `id_banco`) VALUES (3, 454545, '2013-11-25', NULL, 3, NULL, 1, '3333', '3333', '2013-11-07', '2013-11-25', 1, NULL);
INSERT INTO convenio (`id`, `numero_convenio`, `fecha`, `id_hospedaje`, `tipo_convenio`, `id_transporte`, `id_sitio_turistico`, `costo`, `venta`, `fecha_inicio`, `fecha_fin`, `estado`, `id_banco`) VALUES (4, 4294967295, '2013-11-28', 1, 1, NULL, NULL, '2222', '3939390', '2014-03-07', '2014-09-30', 1, NULL);
INSERT INTO convenio (`id`, `numero_convenio`, `fecha`, `id_hospedaje`, `tipo_convenio`, `id_transporte`, `id_sitio_turistico`, `costo`, `venta`, `fecha_inicio`, `fecha_fin`, `estado`, `id_banco`) VALUES (5, 272989289, '2013-12-03', 2, 1, NULL, NULL, '130303', '300001', '2014-03-07', '2014-09-22', 1, NULL);


#
# TABLE STRUCTURE FOR: cuenta
#

CREATE TABLE `cuenta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `estado` bit(1) NOT NULL DEFAULT b'0',
  `usuario` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `password` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_rol` int(10) unsigned NOT NULL,
  `id_usuario` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cuenta_id_rol_idx` (`id_rol`),
  KEY `fk_cuenta_usuario1_idx` (`id_usuario`),
  CONSTRAINT `cuenta_id_rol` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cuenta_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO cuenta (`id`, `estado`, `usuario`, `password`, `id_rol`, `id_usuario`) VALUES (1, 1, 'luis_vargas@gmail.co', '927829892', 2, 1);
INSERT INTO cuenta (`id`, `estado`, `usuario`, `password`, `id_rol`, `id_usuario`) VALUES (2, 0, 'jotver_01@hotmail.com', '1020462279', 3, 2);


#
# TABLE STRUCTURE FOR: detalle_city_tour
#

CREATE TABLE `detalle_city_tour` (
  `id_city_tour` int(10) unsigned NOT NULL,
  `id_sitio_turistico` int(10) unsigned NOT NULL,
  KEY `id_citytour_idx` (`id_city_tour`),
  KEY `id_sitio_turistico_idx` (`id_sitio_turistico`),
  CONSTRAINT `detalle_city_tour_id_citytour` FOREIGN KEY (`id_city_tour`) REFERENCES `citytour` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `detalle_city_tour_id_sitio_turistico` FOREIGN KEY (`id_sitio_turistico`) REFERENCES `sitio_turistico` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

#
# TABLE STRUCTURE FOR: detalle_city_tour_guia
#

CREATE TABLE `detalle_city_tour_guia` (
  `id_guia` int(10) unsigned NOT NULL,
  `id_city_tour` int(10) unsigned NOT NULL,
  KEY `detalle_city_tour_guia_id_guia_idx` (`id_guia`),
  KEY `detalle_city_tour_guia_id_city_tour_idx` (`id_city_tour`),
  CONSTRAINT `detalle_city_tour_guia_id_city_tour` FOREIGN KEY (`id_city_tour`) REFERENCES `citytour` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `detalle_city_tour_guia_id_guia` FOREIGN KEY (`id_guia`) REFERENCES `guia_turistico` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

#
# TABLE STRUCTURE FOR: detalle_hospedaje
#

CREATE TABLE `detalle_hospedaje` (
  `id_convenio` int(10) unsigned DEFAULT NULL,
  `id_hospedaje` int(10) unsigned DEFAULT NULL,
  `costo` float unsigned DEFAULT NULL,
  `venta` float unsigned DEFAULT NULL,
  KEY `hospedaje_convenio_idx` (`id_hospedaje`),
  KEY `convenio_idx` (`id_convenio`),
  CONSTRAINT `convenio` FOREIGN KEY (`id_convenio`) REFERENCES `convenio` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `hospedaje_convenio` FOREIGN KEY (`id_hospedaje`) REFERENCES `hospedaje` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

#
# TABLE STRUCTURE FOR: detalle_idioma
#

CREATE TABLE `detalle_idioma` (
  `id_idioma` int(10) unsigned NOT NULL,
  `id_guia_turistico` int(10) unsigned NOT NULL,
  KEY `detalle_idioma_id_idioma_idx` (`id_idioma`),
  KEY `detalle_idioma_id_guia_idx` (`id_guia_turistico`),
  CONSTRAINT `detalle_idioma_id_guia` FOREIGN KEY (`id_guia_turistico`) REFERENCES `guia_turistico` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `detalle_idioma_id_idioma` FOREIGN KEY (`id_idioma`) REFERENCES `idioma` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

#
# TABLE STRUCTURE FOR: detalle_paquete_hospedaje
#

CREATE TABLE `detalle_paquete_hospedaje` (
  `Id_paquete` int(10) unsigned NOT NULL,
  `id_habitacion_hotel` int(10) unsigned NOT NULL,
  KEY `for_dtlle_paquete_hospedaje_id_paquete` (`Id_paquete`),
  KEY `id_habitacion_hotel_idx` (`id_habitacion_hotel`),
  CONSTRAINT `dtlle_paquete_hospedaje_id_habitacion` FOREIGN KEY (`id_habitacion_hotel`) REFERENCES `habitacion` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `for_dtlle_paquete_hospedaje_id_paquete` FOREIGN KEY (`Id_paquete`) REFERENCES `paquete` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO detalle_paquete_hospedaje (`Id_paquete`, `id_habitacion_hotel`) VALUES (1, 1);
INSERT INTO detalle_paquete_hospedaje (`Id_paquete`, `id_habitacion_hotel`) VALUES (1, 4);


#
# TABLE STRUCTURE FOR: detalle_servicio_adicional
#

CREATE TABLE `detalle_servicio_adicional` (
  `id_hospedaje` int(10) unsigned DEFAULT NULL,
  `id_servicio_adicional` int(10) unsigned DEFAULT NULL,
  `id_sitio_turistico` int(10) unsigned DEFAULT NULL,
  KEY `hospedaje_servicio_adicional_id_hospedaje_idx` (`id_hospedaje`),
  KEY `sitio_turistico_servicio_adicional_id_sitio_idx` (`id_sitio_turistico`),
  KEY `id_servicio_adicional_idx` (`id_servicio_adicional`),
  CONSTRAINT `hospedaje_servicio_adicional_id_hospedaje` FOREIGN KEY (`id_hospedaje`) REFERENCES `hospedaje` (`id`) ON DELETE CASCADE,
  CONSTRAINT `id_servicio_adicional` FOREIGN KEY (`id_servicio_adicional`) REFERENCES `servicio_adicional` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sitio_turistico_servicio_adicional_id_sitio` FOREIGN KEY (`id_sitio_turistico`) REFERENCES `sitio_turistico` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO detalle_servicio_adicional (`id_hospedaje`, `id_servicio_adicional`, `id_sitio_turistico`) VALUES (1, 1, NULL);
INSERT INTO detalle_servicio_adicional (`id_hospedaje`, `id_servicio_adicional`, `id_sitio_turistico`) VALUES (NULL, 9, 3);
INSERT INTO detalle_servicio_adicional (`id_hospedaje`, `id_servicio_adicional`, `id_sitio_turistico`) VALUES (NULL, 7, 3);
INSERT INTO detalle_servicio_adicional (`id_hospedaje`, `id_servicio_adicional`, `id_sitio_turistico`) VALUES (NULL, 8, 3);
INSERT INTO detalle_servicio_adicional (`id_hospedaje`, `id_servicio_adicional`, `id_sitio_turistico`) VALUES (NULL, 9, 3);


#
# TABLE STRUCTURE FOR: evento
#

CREATE TABLE `evento` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci,
  `valor_compra` float unsigned NOT NULL,
  `valor_venta` float unsigned NOT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `cupos` smallint(5) unsigned NOT NULL,
  `lugar` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_salida` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO evento (`id`, `nombre`, `descripcion`, `valor_compra`, `valor_venta`, `direccion`, `cupos`, `lugar`, `fecha_inicio`, `fecha_fin`, `hora_inicio`, `hora_salida`) VALUES (1, 'Concierto Don omar', 'Gran concierto de regueton', '20000', '30000', 'Calle 200 carrera 20000', 35, 'Plaza de toros la macarena', '2014-03-07', '2014-09-23', '10:32:48', '10:32:48');


#
# TABLE STRUCTURE FOR: guia_turistico
#

CREATE TABLE `guia_turistico` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identificacion` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `apellido` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `celular` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

#
# TABLE STRUCTURE FOR: habitacion
#

CREATE TABLE `habitacion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_hospedaje` int(10) unsigned NOT NULL,
  `id_tipohabitacion` int(10) unsigned NOT NULL,
  `comodidades` text COLLATE utf8_spanish_ci,
  `cantidad` tinyint(3) unsigned NOT NULL,
  `valor` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_hotel_idx` (`id_hospedaje`),
  KEY `id_tipo_habitacion_idx` (`id_tipohabitacion`),
  CONSTRAINT `id_hotel1` FOREIGN KEY (`id_hospedaje`) REFERENCES `hospedaje` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `id_tipo_habitacion1` FOREIGN KEY (`id_tipohabitacion`) REFERENCES `tipo_habitacion` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci COMMENT='	';

INSERT INTO habitacion (`id`, `id_hospedaje`, `id_tipohabitacion`, `comodidades`, `cantidad`, `valor`) VALUES (1, 1, 1, 'sillas de agua', 4, '50000');
INSERT INTO habitacion (`id`, `id_hospedaje`, `id_tipohabitacion`, `comodidades`, `cantidad`, `valor`) VALUES (4, 1, 2, '', 3, '49599');
INSERT INTO habitacion (`id`, `id_hospedaje`, `id_tipohabitacion`, `comodidades`, `cantidad`, `valor`) VALUES (5, 1, 7, '', 5, '23999');
INSERT INTO habitacion (`id`, `id_hospedaje`, `id_tipohabitacion`, `comodidades`, `cantidad`, `valor`) VALUES (6, 1, 5, '', 56, '24799');
INSERT INTO habitacion (`id`, `id_hospedaje`, `id_tipohabitacion`, `comodidades`, `cantidad`, `valor`) VALUES (7, 2, 1, 'silla del amor', 4, '60000');


#
# TABLE STRUCTURE FOR: hospedaje
#

CREATE TABLE `hospedaje` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nit` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci,
  `id_categoria` int(10) unsigned NOT NULL,
  `estado` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`id`),
  KEY `id_categrio_idx` (`id_categoria`),
  CONSTRAINT `hospedaje_id_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO hospedaje (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `id_categoria`, `estado`) VALUES (1, '453213', 'HOTEL DAN CARLTON', 'Calle 34 # 34-56', '345 45 67', ' ', 1, 1);
INSERT INTO hospedaje (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `id_categoria`, `estado`) VALUES (2, '2873847832', 'Hotel Plaza', 'la calle', '29083983', '', 1, 1);
INSERT INTO hospedaje (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `id_categoria`, `estado`) VALUES (3, '7687686', 'Hotel Plaza san C', 'calle la 80', '198928938', '', 1, 1);


#
# TABLE STRUCTURE FOR: idioma
#

CREATE TABLE `idioma` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

#
# TABLE STRUCTURE FOR: imagen
#

CREATE TABLE `imagen` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ruta` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_hospedaje` int(10) unsigned NOT NULL,
  `id_habitacion` int(10) unsigned DEFAULT NULL,
  `id_sitio_turistico` int(10) unsigned DEFAULT NULL,
  `id_pago` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `foto_hopedaje_id_hospedaje_idx` (`id_hospedaje`),
  KEY `foto_habitacion_id_habitacion_idx` (`id_habitacion`),
  KEY `foto_sitio_turistico_idx` (`id_sitio_turistico`),
  KEY `imagen_pago_idx` (`id_pago`),
  CONSTRAINT `imagen_habitacion_id_habitacion` FOREIGN KEY (`id_habitacion`) REFERENCES `habitacion` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `imagen_hopedaje_id_hospedaje` FOREIGN KEY (`id_hospedaje`) REFERENCES `hospedaje` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `imagen_pago` FOREIGN KEY (`id_pago`) REFERENCES `pago` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `image_sitio_turistico` FOREIGN KEY (`id_sitio_turistico`) REFERENCES `sitio_turistico` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

#
# TABLE STRUCTURE FOR: novedad
#

CREATE TABLE `novedad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_reserva` int(10) unsigned NOT NULL,
  `fecha` date NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reserva_idx` (`id_reserva`),
  CONSTRAINT `reserva` FOREIGN KEY (`id_reserva`) REFERENCES `reserva` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

#
# TABLE STRUCTURE FOR: pago
#

CREATE TABLE `pago` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `id_banco` int(10) unsigned NOT NULL,
  `id_reserva` int(10) unsigned NOT NULL,
  `forma_pago` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `valor` float unsigned DEFAULT NULL,
  `valor_restante` float unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reserva_idx` (`id_reserva`),
  KEY `id_banco_idx` (`id_banco`),
  CONSTRAINT `id_banco3` FOREIGN KEY (`id_banco`) REFERENCES `banco` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reserva3` FOREIGN KEY (`id_reserva`) REFERENCES `reserva` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

#
# TABLE STRUCTURE FOR: paquete
#

CREATE TABLE `paquete` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_tipo` int(10) unsigned NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `estado` bit(1) NOT NULL DEFAULT b'1',
  `id_sitio` int(10) unsigned DEFAULT NULL,
  `transporte` bit(1) NOT NULL,
  `id_city_tour` int(10) unsigned DEFAULT NULL,
  `id_evento` int(10) unsigned DEFAULT NULL,
  `cupos` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tipo_idx` (`id_tipo`),
  KEY `id_usuario_idx` (`id_usuario`),
  KEY `id_sitio_idx` (`id_sitio`),
  KEY `id_city_tour_idx` (`id_city_tour`),
  KEY `evento_paquete` (`id_evento`),
  CONSTRAINT `evento_paquete` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id`),
  CONSTRAINT `paquete_id_city_tour` FOREIGN KEY (`id_city_tour`) REFERENCES `citytour` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `paquete_id_sitio_turistico` FOREIGN KEY (`id_sitio`) REFERENCES `sitio_turistico` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `paquete_id_tipo_paquete` FOREIGN KEY (`id_tipo`) REFERENCES `tipo_paquete` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `paquete_id_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO paquete (`id`, `id_tipo`, `fecha_inicio`, `fecha_fin`, `id_usuario`, `estado`, `id_sitio`, `transporte`, `id_city_tour`, `id_evento`, `cupos`) VALUES (1, 1, '2014-03-08', '2014-05-09', 1, 1, NULL, 1, 1, 1, 20);


#
# TABLE STRUCTURE FOR: reserva
#

CREATE TABLE `reserva` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fecha_reserva` date NOT NULL,
  `cod_usuario` int(10) unsigned NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `modo_de_pago` bit(1) NOT NULL,
  `cantidad_adultos` smallint(5) unsigned NOT NULL,
  `cantidad_ninios` smallint(5) unsigned NOT NULL,
  `id_paquete` int(10) unsigned DEFAULT NULL,
  `estado` bit(1) NOT NULL DEFAULT b'0' COMMENT 'La reserva debe estar inicialmente desactivada, ya que es el administrador el que la activa una vez compruebe la valides de la misma',
  `id_hospedaje` int(10) unsigned DEFAULT NULL,
  `forma_de_pago` bit(1) NOT NULL,
  `id_evento` int(10) unsigned DEFAULT NULL,
  `id_city_tour` int(10) unsigned DEFAULT NULL,
  `valor_total` float unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_paquete_UNIQUE` (`id_paquete`),
  UNIQUE KEY `id_hospedaje_UNIQUE` (`id_hospedaje`),
  KEY `cliente_idx` (`cod_usuario`),
  KEY `id_paquete_idx` (`id_paquete`),
  KEY `id_hospedaje_idx` (`id_hospedaje`),
  KEY `id_evento_idx` (`id_evento`),
  KEY `id_city_tour_idx` (`id_city_tour`),
  CONSTRAINT `reserva_cliente` FOREIGN KEY (`cod_usuario`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `reserva_id_city_tour` FOREIGN KEY (`id_city_tour`) REFERENCES `citytour` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `reserva_id_evento` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `reserva_id_hospedaje` FOREIGN KEY (`id_hospedaje`) REFERENCES `habitacion` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `reserva_id_paquete` FOREIGN KEY (`id_paquete`) REFERENCES `paquete` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO reserva (`id`, `fecha_reserva`, `cod_usuario`, `fecha_inicio`, `fecha_fin`, `modo_de_pago`, `cantidad_adultos`, `cantidad_ninios`, `id_paquete`, `estado`, `id_hospedaje`, `forma_de_pago`, `id_evento`, `id_city_tour`, `valor_total`) VALUES (1, '2013-11-26', 2, '2013-11-27', '2013-11-27', 1, 1, 0, NULL, 0, 1, 1, NULL, NULL, '2020200');


#
# TABLE STRUCTURE FOR: rol
#

CREATE TABLE `rol` (
  `id` int(10) unsigned NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nivel` tinyint(3) unsigned NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO rol (`id`, `nombre`, `nivel`, `descripcion`) VALUES (1, 'administrador', 5, 'Dueño del software');
INSERT INTO rol (`id`, `nombre`, `nivel`, `descripcion`) VALUES (2, 'empleado', 3, 'Empleado con restricciones');
INSERT INTO rol (`id`, `nombre`, `nivel`, `descripcion`) VALUES (3, 'cliente', 1, 'Cliente de la empresa');


#
# TABLE STRUCTURE FOR: servicio_adicional
#

CREATE TABLE `servicio_adicional` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci,
  `id_tipo_servicio` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_id_tipo_servicio_idx` (`id_tipo_servicio`),
  CONSTRAINT `fk_id_tipo_servicio` FOREIGN KEY (`id_tipo_servicio`) REFERENCES `tipo_servicio` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO servicio_adicional (`id`, `nombre`, `descripcion`, `id_tipo_servicio`) VALUES (1, 'RESTAURANTE', NULL, 1);
INSERT INTO servicio_adicional (`id`, `nombre`, `descripcion`, `id_tipo_servicio`) VALUES (2, 'RESTAURANTE', '', 1);
INSERT INTO servicio_adicional (`id`, `nombre`, `descripcion`, `id_tipo_servicio`) VALUES (3, 'INTERNET GRATIS', NULL, 1);
INSERT INTO servicio_adicional (`id`, `nombre`, `descripcion`, `id_tipo_servicio`) VALUES (4, 'SALA DE REUNIONES', NULL, 1);
INSERT INTO servicio_adicional (`id`, `nombre`, `descripcion`, `id_tipo_servicio`) VALUES (5, 'GIMNASIO', '', 1);
INSERT INTO servicio_adicional (`id`, `nombre`, `descripcion`, `id_tipo_servicio`) VALUES (6, 'PISCINA', NULL, 1);
INSERT INTO servicio_adicional (`id`, `nombre`, `descripcion`, `id_tipo_servicio`) VALUES (7, 'VISTA A LA CIUDAD', NULL, 2);
INSERT INTO servicio_adicional (`id`, `nombre`, `descripcion`, `id_tipo_servicio`) VALUES (8, 'ASCENSOR', '', 2);
INSERT INTO servicio_adicional (`id`, `nombre`, `descripcion`, `id_tipo_servicio`) VALUES (9, 'OTRO', NULL, 2);


#
# TABLE STRUCTURE FOR: sitio_turistico
#

CREATE TABLE `sitio_turistico` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `ubicacion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  `id_tipo_turismo` int(10) unsigned NOT NULL,
  `estado` bit(1) NOT NULL DEFAULT b'1',
  `convenio` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tipo_turismo_idx` (`id_tipo_turismo`),
  CONSTRAINT `sitio_turistico_id_tipo_turismo` FOREIGN KEY (`id_tipo_turismo`) REFERENCES `tipo_turismo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO sitio_turistico (`id`, `nombre`, `ubicacion`, `descripcion`, `id_tipo_turismo`, `estado`, `convenio`) VALUES (1, 'PUEBLITO PAISA', 'CERRO NUTIBARA', '                                                            ', 2, 0, 1);
INSERT INTO sitio_turistico (`id`, `nombre`, `ubicacion`, `descripcion`, `id_tipo_turismo`, `estado`, `convenio`) VALUES (2, 'IGLESIA CANDELARIA', 'MEDELLÍN', '            ', 4, 1, 1);
INSERT INTO sitio_turistico (`id`, `nombre`, `ubicacion`, `descripcion`, `id_tipo_turismo`, `estado`, `convenio`) VALUES (3, 'PARQUE LAS CHIMENEAS', 'ITAGÜÍ', '   ', 3, 1, 1);


#
# TABLE STRUCTURE FOR: tipo_habitacion
#

CREATE TABLE `tipo_habitacion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO tipo_habitacion (`id`, `nombre`, `descripcion`) VALUES (1, 'Individual', '');
INSERT INTO tipo_habitacion (`id`, `nombre`, `descripcion`) VALUES (2, 'Doble', 'Este tipo de habitaciones suelen ofrecerse cuando el hotel, a falta de poder ofertar una habitación con una cama pequeña, dispone al huésped una habitación diseñada para dos personas; obviamente, al ser de mayor tamaño, su precio se eleva.');
INSERT INTO tipo_habitacion (`id`, `nombre`, `descripcion`) VALUES (3, 'Habitación doble', 'Como su nombre lo indica, esta clase de habitaciones son para dos personas. Las camas varían, pueden ser matrimoniales o dos camas individuales independientes.');
INSERT INTO tipo_habitacion (`id`, `nombre`, `descripcion`) VALUES (4, 'Con cama supletoria', 'Estas habitaciones son ideales para quienes viajan con algún menor de edad. Si bien existe un costo por la cama adicional, usualmente suele ser más barato que contratar una habitación triple. Dependiendo de la edad del niño se coloca la cama que mejor le acomode. Algunos hoteles incluso cuentan con cunas para bebés.');
INSERT INTO tipo_habitacion (`id`, `nombre`, `descripcion`) VALUES (5, 'Habitación triple', 'Simple: estas habitaciones cuentan con 3 camas, o 2 más una supletoria. Es perfecta para los viajes con tus amigos.');
INSERT INTO tipo_habitacion (`id`, `nombre`, `descripcion`) VALUES (6, 'Junior Suites', 'cuentan con habitación doble, baño y salón.');
INSERT INTO tipo_habitacion (`id`, `nombre`, `descripcion`) VALUES (7, 'Suites', 'Conocidas por ser las mejores y más lujosas habitaciones en cualquier hotel, cuentan con dos habitaciones dobles, 2 baños, salón y estancia. Por supuesto, su precio es el más elevado. Las suitse más completas y lujosas suelen recibir el nombre de Suite presidencial, y generalmente son reservadas para personajes distinguidos.');
INSERT INTO tipo_habitacion (`id`, `nombre`, `descripcion`) VALUES (8, 'Suite nupcial', 'Pensada para aquellas parejas recién casadas y que quieren disfrutar de una luna de miel con privacidad e intimidad, estas habitaciones en los lugares más exclusivos de los hoteles (generalmente acompañadas sólo por las suite presidencial). Además de una cama matrimonial amplia, generalmente cuentan con jacuzzi y una vista única.');


#
# TABLE STRUCTURE FOR: tipo_paquete
#

CREATE TABLE `tipo_paquete` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO tipo_paquete (`id`, `descripcion`) VALUES (1, 'Vacacional');
INSERT INTO tipo_paquete (`id`, `descripcion`) VALUES (8, 'Gimnacio');


#
# TABLE STRUCTURE FOR: tipo_servicio
#

CREATE TABLE `tipo_servicio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO tipo_servicio (`id`, `nombre`) VALUES (1, 'Hospedaje');
INSERT INTO tipo_servicio (`id`, `nombre`) VALUES (2, 'Sitio turístico');


#
# TABLE STRUCTURE FOR: tipo_turismo
#

CREATE TABLE `tipo_turismo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO tipo_turismo (`id`, `nombre`, `descripcion`) VALUES (1, 'TURISMO CULTURAL', '');
INSERT INTO tipo_turismo (`id`, `nombre`, `descripcion`) VALUES (2, 'TURISMO DEPORTIVO', NULL);
INSERT INTO tipo_turismo (`id`, `nombre`, `descripcion`) VALUES (3, 'TURISMO DE DIVERSIÓN', NULL);
INSERT INTO tipo_turismo (`id`, `nombre`, `descripcion`) VALUES (4, 'TURISMO RELIGIOSO', NULL);
INSERT INTO tipo_turismo (`id`, `nombre`, `descripcion`) VALUES (5, 'TURISMO DE SALUD', NULL);
INSERT INTO tipo_turismo (`id`, `nombre`, `descripcion`) VALUES (6, 'TURISMO DE NATURALEZA', NULL);


#
# TABLE STRUCTURE FOR: tipo_vehiculo
#

CREATE TABLE `tipo_vehiculo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO tipo_vehiculo (`id`, `nombre`, `descripcion`) VALUES (1, 'BUS', '');
INSERT INTO tipo_vehiculo (`id`, `nombre`, `descripcion`) VALUES (2, 'CHIVA', '');


#
# TABLE STRUCTURE FOR: transporte
#

CREATE TABLE `transporte` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nit` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `correo` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `seguro_transporte` bit(1) NOT NULL,
  `estado` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO transporte (`id`, `nit`, `nombre`, `direccion`, `telefono`, `correo`, `seguro_transporte`, `estado`) VALUES (1, '453213', 'BELLANITA', 'CALLE 34 # 34-56', '345 45 60', 'bellanita@gmail.com', 1, 0);
INSERT INTO transporte (`id`, `nit`, `nombre`, `direccion`, `telefono`, `correo`, `seguro_transporte`, `estado`) VALUES (2, '49948338', 'COONATRA', 'CARRERA 12 #90-00', '9874538', 'coonatra@yahoo.com', 1, 1);
INSERT INTO transporte (`id`, `nit`, `nombre`, `direccion`, `telefono`, `correo`, `seguro_transporte`, `estado`) VALUES (3, '0987352', 'COOPETRANSA', 'CALLE 23 # 45-54', '5870092', 'copetransa@gmial.com', 1, 1);


#
# TABLE STRUCTURE FOR: usuario
#

CREATE TABLE `usuario` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identificacion` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `tipo_documento` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `nombres` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `celular` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_nacimiento` date NOT NULL,
  `email` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `tipo` varchar(45) COLLATE utf8_spanish_ci NOT NULL COMMENT 'Se refiere a si es una persona juridica(empresa) o una persona natural',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO usuario (`id`, `identificacion`, `tipo_documento`, `nombres`, `apellidos`, `telefono`, `celular`, `fecha_nacimiento`, `email`, `tipo`) VALUES (1, '927829892', 'CC', 'Luis', 'Vargas', '198928938', '3982982982', '1993-06-12', 'luis_vargas@gmail.co', 'Empleado');
INSERT INTO usuario (`id`, `identificacion`, `tipo_documento`, `nombres`, `apellidos`, `telefono`, `celular`, `fecha_nacimiento`, `email`, `tipo`) VALUES (2, '1020462279', 'CC', 'jhonatan', 'suarez', '3333333333', '30018338389', '1994-08-14', 'jotver_01@hotmail.com', 'Persona Natural');


#
# TABLE STRUCTURE FOR: vehiculo
#

CREATE TABLE `vehiculo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `placa` varchar(45) COLLATE utf8_spanish_ci NOT NULL,
  `id_tipo_vehiculo` int(10) unsigned NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci,
  `cupo_maximo` smallint(5) unsigned NOT NULL,
  `estado` bit(1) NOT NULL DEFAULT b'1',
  `id_transporte` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matricula_UNIQUE` (`placa`),
  KEY `id_tipo_vehiculo_idx` (`id_tipo_vehiculo`),
  KEY `vehiculo_id_transporte_idx` (`id_transporte`),
  CONSTRAINT `id_tipo_vehiculo` FOREIGN KEY (`id_tipo_vehiculo`) REFERENCES `tipo_vehiculo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `vehiculo_id_transporte` FOREIGN KEY (`id_transporte`) REFERENCES `transporte` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO vehiculo (`id`, `placa`, `id_tipo_vehiculo`, `descripcion`, `cupo_maximo`, `estado`, `id_transporte`) VALUES (1, 'AB7654', 2, '', 7, 1, 2);
INSERT INTO vehiculo (`id`, `placa`, `id_tipo_vehiculo`, `descripcion`, `cupo_maximo`, `estado`, `id_transporte`) VALUES (2, '8765GA', 2, '', 33, 1, 3);
INSERT INTO vehiculo (`id`, `placa`, `id_tipo_vehiculo`, `descripcion`, `cupo_maximo`, `estado`, `id_transporte`) VALUES (3, '98766Z', 2, 'Es una chiva Navideña', 10, 1, 3);


